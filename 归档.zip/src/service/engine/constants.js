var DOM_READY_EVENT = '__DOMReady'
// var UPDATE_APP_DATA = "__updateAppData";

export { DOM_READY_EVENT }
