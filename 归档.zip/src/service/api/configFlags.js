// module6

export default {
  AppStatus: {
    FORE_GROUND: 0,
    BACK_GROUND: 1,
    LOCLOCKK: 2
  }
}
