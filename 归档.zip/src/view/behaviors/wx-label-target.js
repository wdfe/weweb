// wx-label-target
window.exparser.registerBehavior({
  is: 'wx-label-target',
  properties: {},
  handleLabelTap: function (event) {}
})
