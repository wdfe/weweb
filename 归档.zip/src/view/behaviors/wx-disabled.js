// wx-disabled
export default window.exparser.registerBehavior({
  is: 'wx-disabled',
  properties: {
    disabled: {
      type: Boolean,
      value: !1,
      public: !0
    }
  }
})
