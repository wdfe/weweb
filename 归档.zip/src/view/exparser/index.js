import * as main from './main'
window.exparser = main
