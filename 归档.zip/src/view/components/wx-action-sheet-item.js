// wx-action-sheet-item
export default window.exparser.registerElement({
  is: 'wx-action-sheet-item',
  template: '\n    <slot></slot>\n  ',
  properties: {},
  behaviors: ['wx-base']
})
