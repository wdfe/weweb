#!/bin/sh
npm run build
NODE_ENV=production ./bin/weweb demos/demo20170111